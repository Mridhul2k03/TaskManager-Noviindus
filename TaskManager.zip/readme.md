## Sample Users and Credentials

### Main Admin
- **Username:** `admin`  
- **Password:** `admin`

### Regular Users
| Username | Password          |
|----------|-------------------|
| user1    | user1@gmail.com   |
| user2    | user2@gmail.com   |
| user3    | user3@gmail.com   |
| user4    | user4@gmail.com   |

### Admins
- **Username:** `admin2`  
- **Password:** `admin2@gmail.com`

### Super Admin
- **Username:** `superadmin`  
- **Password:** `superadmin@gmail.com`
